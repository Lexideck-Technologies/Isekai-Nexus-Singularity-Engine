Creative Commons Attribution-ShareAlike 4.0 International

Copyright (c) 2025-2026 Lexideck Technologies

This work is licensed under the Creative Commons Attribution-ShareAlike 4.0
International License. To view a copy of this license, visit
https://creativecommons.org/licenses/by-sa/4.0/ or send a letter to
Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

You are free to:

  Share - copy and redistribute the material in any medium or format for
  any purpose, including commercially.

  Adapt - remix, transform, and build upon the material for any purpose,
  including commercially.

Under the following terms:

  Attribution - You must give appropriate credit, provide a link to the
  license, and indicate if changes were made. You may do so in any
  reasonable manner, but not in any way that suggests the licensor
  endorses you or your use.

  ShareAlike - If you remix, transform, or build upon the material, you
  must distribute your contributions under the same license as the
  original.

  No additional restrictions - You may not apply legal terms or
  technological measures that legally restrict others from doing anything
  the license permits.

Notices:

  You do not have to comply with the license for elements of the material
  in the public domain or where your use is permitted by an applicable
  exception or limitation.

  No warranties are given. The license may not give you all of the
  permissions necessary for your intended use. For example, other rights
  such as publicity, privacy, or moral rights may limit how you use the
  material.

For the full legal code, see:
https://creativecommons.org/licenses/by-sa/4.0/legalcode
