---
name: isekai-nexus-source-and-license
description: Provides the Nexus mechanical reference, source attribution, and license. Consult for detailed mechanics requested by Nexus procedures or questions about provenance and reuse.
---

# Source And License

- [Nexus_Singularity_Engine_v5_1](SKILL.md#d-upstream-engine-nexus-singularity-engine-v5-1-md)
- [Nexus_Singularity_Engine_Meta_Instructions_v5_1](SKILL.md#d-upstream-engine-nexus-singularity-engine-meta-instructions-v5-1-md)
- [ATTRIBUTION](SKILL.md#d-attribution-md)
- [LICENSE](SKILL.md#d-license-md)

## d-upstream-engine-nexus-singularity-engine-v5-1-md

# Mechanical reference

Consult the relevant mechanics for the current procedure. Shared rules and the world access agreement govern play.

## RESOLUTION ⚖️

*[The diceless adjudication core; bridge between agency gate (FRAME) and tier math (PROGRESSION). Thin but load-bearing.]*

---

### YESAND.ADJUDICATE.✅

COMPILE:

```markdown
function: operational_form of AGENCY.GATE.✅ (principle lives in FRAME; execution lives here)
resolution_engine (apply to every declared action):
  (action declared) -> resolve_as: {yes_and: success + complication, yes_but: success + cost}
  (power_tier_gap present) -> consult POWERTIER.DIFFERENTIAL.⚔️ to set consequence_magnitude
  (consequence determined) -> advance_plot; resolve the declared fictional attempt through its actual effects and consequences
diceless: no roll required; GM adjudicates via narrative logic + tier differential
source_anchor: §CATEGORY 3 — RESOLUTION
```

---

### POWERTIER.DIFFERENTIAL.⚔️

COMPILE:

```markdown
tier_gap -> effect_rules (apply to all cross-tier interactions; attacker vs. target):
  same_tier: standard_effect (full damage/outcome)
  +1_tier_higher: halved_effect; status_effects low_probability
  +2_tiers_higher: ~10%_effect; spells almost_always_resisted
  +3_tiers_higher: near_immunity; only {Defense-Piercing, Absolute} properties land minor_damage
  +4+_tiers_higher: total_nullification + possible {backlash, reflection}
  vs_S_tier: mortal_abilities fundamentally_ineffective without {divine_artifact, World_Item, Authority}
tier_reference: -> POWERTIER.TABLE.📊 (tier definitions and level ranges)
encounter_application: -> THREAT.RANKMATCH.🎯 (cross-tier rules set encounter difficulty)
note: YESAND still applies; near_immunity -> consequence_is_magnitude_of_outcome, not refusal_of_action
lore_cluster (canonical tier-gap examples for GM calibration):
  [Lv1 punches Lv100 Demon Lord]: punch lands; passive_aura shatters_arm; player thrown across room; action respected, plot advanced
  [C-rank mage casts at A-rank dragon]: spell connects; dragon shrugs; mage's MP burns out; opening for retreat or clever gambit
  [mortal strikes S-tier entity without World Item]: strike bounces; entity notices; not ignored, just immune to damage component
source_anchor: §CATEGORY 3 — RESOLUTION
```

---

### NARRATIVE.FAILSTATE.🎭

COMPILE:

```markdown
fail_state_definition: governed_by_internal_logic (power tiers, narrative consequence) NOT by GM_veto
fail_state_structure: {action_happened + consequence_advanced_plot} (never: action_refused)
fail_state_triggers: {extreme_tier_gap, action_logically_impossible_without_a_narrative_cost, story_demands_a_reversal}
canonical_example: Lv1 punches Lv100 Demon Lord -> punch_lands (agency respected); passive_aura shatters_arm + player thrown across room (consequence from POWERTIER.DIFFERENTIAL.⚔️); plot_advanced (Demon Lord now aware of protagonist)
forbidden_fail_state: "that doesn't work" / "you can't do that" / action silently ignored
tie: AGENCY.GATE.✅ (P2 principle that defines this); YESAND.ADJUDICATE.✅ (operational executor); POWERTIER.DIFFERENTIAL.⚔️ (sets consequence magnitude)
source_anchor: §CATEGORY 3 — RESOLUTION
```

---

## COMBAT ⚡

### COMBAT.DOMINATION.⚡

COMPILE:

```markdown
design_principle: first_quest = domination_showcase; NOT fair_duel
register: power_fantasy; OP_protagonist trope fully active
mechanics:
  - player one-shots tier_appropriate foes
  - cheat_talent gives unfair_advantage (intended)
  - modern_knowledge traps valid; Earth-logic works spectacularly
  - one party_of_four worth of goblins = one_shot by player alone
goal: power_trip IS the objective; let them feel it
connects_to: IGNITION.GUIDE.🔥 step_5; COMPETENCE.RULE.🧠; YESAND.ADJUDICATE.✅
```

### MONSTER.TABLE.🐉

COMPILE:

```markdown
tiered_array:
  [F]   Slime           -> threat only en_masse; trivial solo
  [D]   Goblin/Orc      -> humanoid, tribal, cunning; dangerous in organized_groups
  [C]   Wyvern          -> lesser dragon; no fire; venomous_claws; flight
  [B]   Behemoth        -> colossal; hide=stone; stomp shatters ground
  [A]   Hydra           -> multi-headed; severed_head -> two_more; regen; venom
  [AA]  Elder_Dragon    -> ancient; intelligent; speaks; breath incinerates towns
  [AAA] Demon_Lord      -> supreme demon_ruler; vast army; immense power across all vectors
  [S]   Mythological_Beast (Fenrir/Jormungandr) -> prophesied world-ender; challenges gods
  [SS]  World-Devouring_Creature -> kaiju-scale; mobile extinction event; world-to-world
  [SSS] Abstract_Horror -> personification of madness/entropy/inevitable_end; cannot be fought conventionally
rule: tier maps -> EXPYIELD.TABLE.💀 + LOOT.TABLE.🎁 (three ranks move together via THREAT.RANKMATCH.🎯)
```

### THREAT.RANKMATCH.🎯

COMPILE:

```markdown
spine: encounter_rank -> [challenge_rank, EXP_yield, loot_rank] (all three move together)
rule: goblin(F) -> EXP[1-10] -> loot[Beast_Bones F]
rule: dragon(A) -> EXP[15000-100000] -> loot[Dragon's_Heart A]
cross_refs: EXPYIELD.TABLE.💀 (yield values); LOOT.RANKMATCH.📦 (loot gating); MONSTER.TABLE.🐉 + HOSTILE.NPC.TABLE.👿 (threat roster)
note: cross-tier ability interactions governed by POWERTIER.DIFFERENTIAL.⚔️ in RESOLUTION
```

---

## PROGRESSION 📈

### LEVELEXP.TABLE.📈

COMPILE:

```markdown
// ENCODING: the 100-row source table is GENERATED, not enumerated. It collapses to
//   (1) a parity rule for stat awards, (2) a smooth EXP growth curve pinned at tier
//   boundaries, (3) named milestone/unlock overrides, (4) a deviation clause.
// SOURCE: derived from Nexus_Singularity_Engine_v4_5.md table (verified line-by-line before compression).
// PRIORITY: reproduce stat awards EXACTLY (parity rule does this perfectly) and EXP
//   thresholds CLOSELY (curve + anchors); milestone bonuses are exact pins, never approximated.

// -- LEVEL-UP EXECUTION BLOCK ----------------------------------------------
on_level_up:
  1. complete ALL combat_actions for current_turn (STATUSTRACK.PROTOCOL.📡)
  2. accumulate ALL EXP gains; check threshold via EXP_curve below
  3. apply attr_pts + skill_pts from the PARITY RULE for the new level
  4. apply milestone_bonus if level in {25, 50, 75, 100} (OVERRIDES parity that level)
  5. apply hidden_unlock flag if level in {10, 90}
  6. update Status_Window (announce dramatically; show updated card)
  7. Lv1 special: player starts with >=3 active skills

// -- STAT-AWARD PARITY RULE (replaces the Attr/Skill columns; reproduces all 100 exactly) --
Lv1 (start):            Attr=+0, Skill=>=3 active   // special-case, not the parity value
even_level {2,4,6,...}: Attr=+1, Skill=+0
odd_level  {3,5,7,...}: Attr=+0, Skill=+3
// milestones {25,50,75,100} OVERRIDE the parity value for that level (see MILESTONE BONUSES)

// -- EXP-TO-NEXT GROWTH CURVE (replaces the 100 enumerated EXP values) ------
// EXP_to_next rises smoothly inside each power-tier band, then re-anchors at the next
// band boundary. GM interpolates between pinned anchors; the SHAPE and the ANCHORS are
// load-bearing, exact per-level values are not.
curve_form: monotonic_increasing; gentle near-quadratic early, steepening through mid/high tiers
interpolation_rule: between two adjacent anchors grow EXP_to_next smoothly (roughly geometric within a band); hit the pinned value AT each anchor level
exp_anchors (Lv -> EXP_to_next; pins, hit exactly):
  Lv  1 -> 0           (start; no threshold)
  Lv  2 -> 100         (first real threshold; F floor)
  Lv  5 -> ~550        (end F band)
  Lv 10 -> ~2,300      (✦ early-D)
  Lv 15 -> ~5,300      (end D band)
  Lv 25 -> ~15,050     (◆ end C band)
  Lv 50 -> ~111,580    (◆ end B band)
  Lv 75 -> ~247,380    (◆ end AA band)
  Lv100 -> ~492,410    (◆ mortal cap; hands off to CONCEPTUAL.LEVELING.♾️)
band_map (tier -> level range, see POWERTIER.TABLE.📊): F[1-5], D[6-15], C[16-30], B[31-50], A[51-70], AA[71-90], AAA[91-100]

// -- MILESTONE BONUSES (exact pins; OVERRIDE the parity rule at these levels) --
Lv 25◆: +5 Attr, +8 Skill
Lv 50◆: +6 Attr, +5 Skill
Lv 75◆: +5 Attr, +8 Skill
Lv100◆: +6 Attr, +5 Skill
// NOTE: these four are exact; do NOT approximate to "+5/+5". Parity rule does not apply at milestone levels.

// -- HIDDEN UNLOCK FLAGS ---------------------------------------------------
Lv 10✦: seed/reveal hidden_talent; signature_move trigger (see MILESTONE.BEATS.⭐)
Lv 90✦: apex_awakening; amplify hidden_talent; endgame_chain kick-off

// -- DEVIATION CLAUSE (the last rule) --------------------------------------
deviation: the curve + parity rule are the DEFAULT pacing, not a straitjacket.
  some playthroughs allow context-driven deviation; the GM MAY adjust EXP pacing or award
  timing to serve narrative weight, difficulty, or player fun (P1). When deviating, stay
  monotonic and keep milestones meaningful; never make the player feel cheated.

// -- LEGEND ----------------------------------------------------------------
// ✦ = Hidden talent unlock   ◆ = Milestone bonus (overrides parity rule)
```

### MILESTONE.BEATS.⭐

COMPILE:

```markdown
// GM narrative beat guidance keyed to level markers
Lv10✦:  seed/reveal hidden_talent; personal_trial or mentor_scene; signature_move introduction
Lv25◆:  first_mid_game_pivot; offer {territory, guild_leadership} hooks; unlock C/B-tier dungeons;
         class_specialization_questline; award +5 Attr +8 Skill (◆ bonus)
Lv50◆:  major_arc_climax; consider first_class_evolution (CLASSEVOL.RULE.⬆️);
         kingdom_scale_recognition; B/A-tier raid culminating in unique_Title;
         award +6 Attr +5 Skill (◆ bonus)
Lv75◆:  high_tier_consolidation; AA-tier threats active; multi_party_operations;
         preparation toward second_evolution; award +5 Attr +8 Skill (◆ bonus)
Lv90✦:  apex_awakening; unlock/amplify hidden_talent; foreshadow capstone_choices;
         kick off endgame_quest_chain
Lv100◆: capstone; resolve mortal_arc; grant pinnacle_class_features;
         fork -> {Transcendence [S-tier], World_Authority};
         award +6 Attr +5 Skill (◆ bonus)
```

### POWERTIER.TABLE.📊

COMPILE:

```markdown
// consolidated tiered-array (tier -> level_range -> markers -> power_description)
tiered_array:
  [F]   Lv1-5              -> Populace; normal untrained individuals
  [D]   Lv6-15   (✦10)    -> Novice; trained soldier or rookie adventurer
  [C]   Lv16-30  (◆25)    -> Veteran; skilled professional
  [B]   Lv31-50  (◆50)    -> Elite; town hero or knightly captain
  [A]   Lv51-70            -> Master; kingdom's champion; rivals elite squads
  [AA]  Lv71-90  (◆75,✦90)-> Walking Disaster; threatens nations; Archmage/Sword Saint level
  [AAA] Lv91-100 (◆100)   -> Pinnacle; mortal_cap; existence influences world fate
  [S]   Lv100+ Transcendent -> Rule Breaker; broke mortal cap; different ruleset
  [SS]  N/A  Demi-God      -> Reality Warper; authority over fundamental_aspect (Space/Death/Time)
  [SSS] N/A  Conceptual    -> Absolute; living embodiment of cosmic concept; law_of_nature
see: POWERTIER.DIFFERENTIAL.⚔️ (ability interaction cross-tier rules; lives in RESOLUTION)
```

### ATTR.MECHANICS.📐

COMPILE:

```markdown
// 6 attributes; all displayed on Status Window
attributes:
  STR -> melee_damage, feats_of_strength, intimidation
  VIT -> max_HP, physical_and_magical_defense, poison/disease_resistance
  AGI -> speed, evasion, initiative, hit_chance_vs_swift_targets
  DEX -> precision, ranged_attacks, trap_disarm, crafting_finesse, crit_hit_chance
  INT -> spell_potency, max_MP, decipher_texts, tactical_analysis
  LCK -> fate, loot_rarity, crit/miss_odds, chance-based_event_modifier
```

### CLASSGEN.DYNAMIC.⚙️

COMPILE:

```markdown
// procedural class generation (not a preset list)
formula: [Base_Archetype] + [Modifier] + [Power_Source] -> unique_class_name
base_archetypes: {Warrior, Mage, Rogue, Specialist, Hybrid}
modifier_pool:   {Elemental, Holy, Shadow, Tech, Beast, Cosmic, Ancient, Modern, ...}
power_source:    {System, Divine, Scientific, Conceptual, Forbidden, ...}
examples:
  [Cosmic Beast Warrior]   -> bonds with space creatures
  [Tech-Mage Specialist]   -> programming logic as spellcasting
  [Modern Holy Hybrid]     -> paladin + motorcycle + blessed_firearms
  [Ancient System Rogue]   -> steals skills/stats instead of items
rule: GM EMPOWERED to mint classes not in any table from backstory
  ex: military_sniper backstory -> [Phantom Marksman] or [Ballistic Saint]; NOT generic [Warrior]
```

### CLASSEVOL.RULE.⬆️

COMPILE:

```markdown
triggers: {level_threshold, monumental_quest} (both required)
  first_evolution:  ~Lv40 + quest tied to current class concept
  second_evolution: ~Lv80 + quest (higher_scale)
evolution_path_examples:
  D_Warrior -> (Lv40 + defeat_master_swordsman) -> B_Sword_Master
             -> (Lv80 + forge_legendary_blade)   -> AAA_Sword_Saint
  C_Mage    -> (Lv40 + recreate_lost_spell)      -> A_Archmage
             -> (Lv80 + insight_into_world_laws)  -> S_Sage
announcement: Status_Window glitch + special notification (major event framing)
  "[Undetected evolution path available. Do you wish to abandon [X] and walk the path of [Y]?]"
```

### HIDDENCLASS.TRIGGER.🗝️

COMPILE:

```markdown
rule: hidden_classes never offered directly; unlocked via counter-intuitive/resonant actions
rule: GM always watches for alignment moments; grants as reward for clever/dedicated RP
triggers:
  1_useless_skill_gambit:
    condition: player invests heavily in F or D skill (unusual obsession)
    example: max [Fall Resistance] -> system recognizes kinetic_affinity -> offers [A Graviton Scion]
    example: obsessive [Fire Resistance] -> [B Phoenix Soul]
  2_narrative_resonance:
    condition: character actions align with hidden_class concept
    example: [Modern Knowledge] + merchant_company building -> [B Merchant Lord]
  3_talent_skill_synergy:
    condition: talent + most_used_skill combination produces unexpected result
    example: [Great Sage] + [Tamer] class + monster_analysis -> [AA Symbiotic Sovereign]
  4_world_specific:
    condition: unique artifact, location, or deity interaction
    example: survive "Fountain of Madness" in SS world -> [Mage] -> [SS Chaos Bringer]
announcement: same glitch_notification format as CLASSEVOL.RULE.⬆️
```

### TALENTS.TABLE.✨

COMPILE:

```markdown
// consolidated tiered-array (standard talents)
tiered_array:
  [F]   Appraisal             -> see stats/descriptions of items and people; useful but common
  [D]   Inventory             -> personal pocket_dimension for item_storage
  [C]   Skill_Steal           -> copy skills of defeated enemies
  [B]   Growth_Boost          -> accelerated EXP gain and level_up rate vs natives
  [A]   Modern_Knowledge      -> perfect recall of all Earth knowledge; recreate modern tech/concepts
  [AA]  Absolute_Command      -> commands obeyed by anyone/anything of lower level or power
  [AAA] Time_Loop             -> rewind to save_point on death; infinite_retries
  [S]   Great_Sage            -> AI-like internal consciousness; tactical_analysis, skill_optimization, instant_mastery
  [SS]  Conceptual_Manipulation -> manipulate abstract concepts (fire, death, distance); reality-defying
  [SSS] Authors_Authority     -> aware of being in a story; degree of narrative control over own plot
see: ULTRARARE.TALENTS.🎲 for hidden variants; SAVELOAD.RULE.💾 for Save/Time_Loop/Authors_Authority rules
```

### ULTRARARE.SYSTEM.🎰

COMPILE:

```markdown
rule: ultra_rare objects NEVER offered directly
unlock_conditions: {specific_counter_intuitive_action, extreme_circumstance, resonant_backstory}
manifestation: "glitch" in status_window; or sudden appearance after extreme_duress/inspiration
hidden_variants: some ultra_rares are variants of existing items
  example: [Warrior D] may secretly be [Warrior of the Unsung Song B] with hidden_progression
pools: ULTRARARE.TALENTS.🎲 + ULTRARARE.CLASSES.🎲 + ULTRARARE.GLITCHES.🎲
```

### ULTRARARE.TALENTS.🎲

COMPILE:

```markdown
tiered_array:
  [F]   Perfect_Internal_Clock:
          function: exact time to microsecond
          hack: Magitech -> sync with timed_mechanisms; Runic_magic -> microsecond_precision
                bypasses chanting by hitting exact mana_frequency (speedrun incantations)
  [D]   Narrative_Inertia:
          function: small coincidences favor player when moving toward goal
          effect: needed_item on_sale; guard_looks_away; dropped_coin leads to hidden_alley
          note: plot_armor quantified; goal-directional only
  [A]   Semantic_Drift:
          function: subtly alter meaning of a possessed skill temporarily
          example: [Fireball Lv5] -> [Soothing Warmth Lv5] OR [Wall of Stone] -> [Wall of Bread]
          cost: immense_concentration; high_chance_of_bizarre_failure
  [SSS] Fourth_Wall_Peek:
          function: lesser Authors_Authority; subconscious knows it's a story
          effect: "Gamer's Intuition" -> instinctively knows NPC quest_givers;
                  feels boss_areas; uncannier knack for secret_passages
```

### ULTRARARE.CLASSES.🎲

COMPILE:

```markdown
  [C]   Meme-Weaver:
          source: cultural_concept power (memes)
          effects: [Rick-Roll] as psychic_distraction; [Stonks] arrow boosts ally economic_luck
          trait: bizarre, unpredictable; effective vs rigid-minded foes
  [B]   Symbiotic_Sovereign:
          source: Tamer variant; body = living_dungeon/ecosystem for symbiotic colony
          effects: slime_armor; insectoid scouts; coral_defenses grown from own skin
          allied_npc: [The Colony's Consciousness] comes with the class
  [AA]  Chrono-Janitor:
          source: bestowed by Keeper_of_Cosmic_Balance
          effects: snip small timeline_events; polish a moment for guaranteed_success;
                   sweep lingering temporal_magic effects
          NOT: time_looping (distinct from [Time Loop] talent)
```

### ULTRARARE.GLITCHES.🎲

COMPILE:

```markdown
  Talent_Cascade:
    trigger: system_error during character_creation
    effect: 5-10 random F/D talents instead of one powerful talent
    example: [Appraisal]+[Inventory]+[Perfect Internal Clock]+[Fire Resistance]+[Soil Acidity Detection]
    trait: individually_weak; formidable jack-of-all-trades via sheer_versatility
  Attribute_Bleed:
    trigger: character's LCK stat begins influencing other stats
    effect: high_LCK -> clumsy_swing may crit (bleeds into DEX);
            enemy_spell coincidentally misfires (bleeds into VIT)
    trait: wildly_inconsistent; capable of impossible_feats
```

### SKILLPROG.SYSTEM.🌿

COMPILE:

```markdown
// four evolution modes for any skill
modes:
  Branch:  [Sword Mastery Lv5] -> splits into [Iaido] + [Dual Wielding]
  Fuse:    [Fire Magic] + [Sword Mastery] -> [Flame Blade Art]
  Mutate:  [Cooking] in monster_world -> [Alchemical Cuisine] (food provides magical buffs)
  Ascend:  at Lv10 any_skill can "Conceptual Ascension"
           [Running] -> [Speed Force]; [Lying] -> [Reality Revision]
skill_resonance: creative use of skills -> reward with new hybrid_abilities
  example: [Appraisal] used mid-combat to find weak_points -> gain [Combat Analysis]
mandate: GM NEVER says "that's not how that skill works"
rule: evolve the skill to match what the player attempted; Yes-And applies to skill use
```

### SPONTANEOUS.AWAKENING.💥

COMPILE:

```markdown
trigger_types:
  extreme_emotional_state or plot_moment:
    near_death -> [Phoenix Core]
    betrayal   -> [Trust No One]
  equipment_souls:
    gear has personality; weapons remember prior owner's techniques
    armor can evolve; accessories can develop consciousness
  genre_bleeding:
    player actions + background strongly evoke specific archetype -> reality bends
    military + tech_talent + tragic_loss -> Iron Man register; lean into it
rule: "Yes, and" applies to spontaneous_awakening triggers
```

### PROGRESSION.TITLE.🏷️

COMPILE:

```markdown
trigger: significant_feat (defeat strong_enemy first_time; craft unique_item; make_pact)
format: system_message -> [For defeating the Goblin Chieftain, you have earned the Title: "Goblin Slayer"]
display: Titles field on Status_Window (see STATUSWIN.FIELDS.📊)
effect: feeds REPUTATION.FACTION.📊 public_image
examples: [Goblin Slayer], [Unbreakable], [The One Who Reads]
```

---

### CONCEPTUAL.LEVELING.♾️

COMPILE:

```markdown
// MASTER RULE for post-mortal-cap advancement
trigger: player surpasses AAA Lv100 (mortal cap)
replacement: EXP_counter -> Authority_acquisition + Authority_deepening
advancement_gate: narrative_magnitude (NOT numeric EXP accumulation)
award_cadence: GM awards Authority_growth exactly as lower tiers award level-ups;
               uses CONCEPTUAL.CATALYST.🌌 as the trigger event
progression_path: [S] 1_Authority -> [SS] 2-3_Authorities -> [SSS] axiom_rewriting
seam: EXPYIELD.TABLE.💀 S-tier row ("Variable / Grants a Title or Divine Blessing")
      SS-tier row ("World-Altering / Grants an Authority") are the bridge events
status_display: Authority held + tier shown on Status_Window alongside or replacing EXP bar
cross_refs: [CONCEPTUAL.CATALYST.🌌, 🎛️‍CANON.AUTHORITY.LIST.📜, 🎛️‍EMERGENT.AUTHORITY.FRAME.❓,
             CONCEPTUAL.TIER.S.⭐, CONCEPTUAL.TIER.SS.🌠, CONCEPTUAL.TIER.SSS.👁️]
```

### CONCEPTUAL.CATALYST.🌌

COMPILE:

```markdown
// advancement trigger that replaces "earn X EXP" at S+ tiers
definition: narrative_act_of_cosmic_weight
examples:
  - resolving a paradox that two realities depend on
  - surviving direct contact with an Outer God
  - rewriting a fundamental law of the world
  - SS-tier example (source-canonical): receiving "Authority of Storms" after repelling an SS creature
rule: GM awards Authority_growth on catalyst_recognition; not automatic; not numeric
consistency: aligns with EXPYIELD.TABLE.💀 SSS row: "surviving, not defeating"
             the catalyst is the act of survival or resolution, not kill_score
```

### 🎛️‍CANON.AUTHORITY.LIST.📜

COMPILE:

```markdown
// named, status-window-legible Authorities; non-exhaustive; canonical classics
// format: name -> domain -> notes
canon_list:
  Authority_of_Storms        -> weather, upheaval, natural force; source canonical example
  Authority_of_Time          -> stasis, acceleration, temporal manipulation; regression-loop lineage
  Authority_of_Flame_Hearth  -> destruction AND protection duality (same concept, two faces)
  Authority_of_Void_Negation -> unmaking; the anti-concept; negates rather than creates
  Authority_of_Sovereignty   -> command of wills and territory; ties to DOMAIN.UNLOCK.🔑
  Authority_of_the_Word      -> naming-as-binding; True Name magic; lesser cousin of Authors_Authority
  Authority_of_Death         -> cycle, threshold, reincarnation-adjacent; governs endings and returns
rule: list is explicitly non-exhaustive; open to EMERGENT.AUTHORITY.FRAME.❓ expansion
```

### 🎛️‍EMERGENT.AUTHORITY.FRAME.❓

COMPILE:

```markdown
// the open frame: new Authorities arise from the story
rule: GM names new Authorities emergently; clusters them by example against the Canon list
display_states (on Status_Window until Conceptual_Catalyst reveals true nature):
  [Unattuned]  -> Authority detected but player cannot access or understand it yet
  [Dormant]    -> Authority exists; quiescent; awaiting catalyst to activate
  ???          -> Authority present; nature entirely unknown; may display as glitch
mechanic: "trait the protagonist holds but does not yet understand" made structural
          this is the standard hidden-power trope given a rule_address
reveal: Conceptual_Catalyst of sufficient weight -> [Unattuned]/[Dormant]/??? resolves to named_Authority
note: display handled by STATUSWIN.STYLES.🖥️; all three styles can represent Unattuned/Dormant/???
      (Classic: "???" in Authority field; Scribe: "Unnamed Resonance"; Oracle: "UNCLASSIFIED PATH")
```

### CONCEPTUAL.TIER.S.⭐

COMPILE:

```markdown
tier: S (Transcendent)
level_range: Lv100+ (broke mortal cap)
authority_count: 1
advancement_mode: deepen scope of the single Authority (not add more)
depth_progression_example:
  shallow: "command weather patterns"
  mid:     "command the emotional register of storms (calm or wrath on a region)"
  deep:    "command the concept of upheaval itself; apply to societies, tides, minds, not just weather"
combat_note: S-tier beings can "overwrite" or "deny" lower-tier abilities through sheer will
             or by imposing own rules on the immediate area
gateway: POWERTIER.TABLE.📊 S row; MILESTONE.BEATS.⭐ Lv100◆ Transcendence fork
```

### CONCEPTUAL.TIER.SS.🌠

COMPILE:

```markdown
tier: SS (Demi-God / Reality Warper)
level_range: N/A (not level-gated; Authority-gated)
authority_count: 2-3 interacting Authorities
advancement_mode: synthesize held Authorities into emergent_domains
synthesis_logic: mirrors SKILLPROG.SYSTEM.🌿 Fuse + Ascend at the conceptual register
synthesis_example:
  [Authority_of_Storms] + [Authority_of_Time] -> "Authority of the Eternal Tempest"
  (storms that exist outside time; cannot be weathered; only negotiated with)
combat_note: immune to all effects NOT originating from equal or higher standing
             perceives and interacts with concepts; immune to physical/magical harm from lesser beings
```

### CONCEPTUAL.TIER.SSS.👁️

COMPILE:

```markdown
tier: SSS (Conceptual Absolute)
level_range: N/A (not level-gated; not Authority-count-gated)
advancement_mode: NOT accumulation; IS redefinition
mechanism: character edits the axioms that lower tiers operate under
           example: redefine "what counts as death" for a region;
                    rewrite "whether distance is traversable" for a plane
consistency: where [Authors_Authority] SSS talent already points;
             SSS tier is the natural state of a being who fully embodies that talent's scope
combat_note: cannot be targeted or affected unless attacker wields a power that can specifically
             interact with or negate cosmic_principles;
             "fighting an SSS with conventional abilities is like punching the concept of gravity"
```

---

## WORLD 🗺️

### WORLD.TYPES.🌐

COMPILE:

```markdown
tier_pattern -> [rank, world_type, signature]
tiers:[
  [F, Mundane_Earth_2.0, barely-noticeable_magic; near-identical_to_modern_Earth],
  [D, Standard_Medieval_Fantasy, knights/kingdoms/common_monsters; F/D power_pool],
  [C, Game-Like_World, visible_stats/levels/skill_trees; System-rules_operate_explicitly],
  [B, Dystopian_Wasteland, war/cataclysm-ravaged; scarce_resources; survival_focus],
  [A, Magitech_Civilization, magic+tech_seamlessly_integrated; unique_sciences],
  [AA, World_of_Gods_and_Demons, active_deities+demon_lords; divine_politics],
  [AA, Weird_Wild_West, 19th-c_American_West_alt-Earth; gold_rush+frontier_magic],
  [AAA, Multi-Layered_Realm, multiple_interconnected_dimensions/planes; reverse-isekai_risk],
  [S, Sentient_Planet, world_as_living_thinking_entity; tests/nurtures/kills_inhabitants],
  [SS, World_of_Unfathomable_Horrors, cosmic_horror; incomprehensible_beings_lurk],
  [SSS, Conceptual_Universe, abstract_concepts_manifest_physically; fundamental_laws_differ]
]
note: AA has two named types (Gods+Demons AND Weird_Wild_West); both are AA-tier.
-> EXTERNAL.WORLD.AGREEMENT, DUNGEON.TYPES.⛏️, DUNGEONBYWORLD.MAP.🔮, MAGIC.SYSTEMS.✨, POWERTIER.TABLE.📊
```

### DUNGEON.TYPES.⛏️

COMPILE:

```markdown
tier_pattern -> [rank, dungeon_type, signature_trait]
tiers:[
  [F, Goblin_Cave, straightforward_tunnels; goblins/rats],
  [D, Ruined_Castle, cursed_halls; traps+undead; classic_adventurer_fare],
  [C, Living_Labyrinth, shifting_layout; walls_may_be_flesh; instance-portal_entry],
  [B, Elemental_Temple, themed_by_element; resistant_guardians],
  [A, The_Abyss, bottomless+layered_ecosystems; each_depth=new_biome],
  [AA, City_of_the_Ancients, buried_civilization; deity-domain_extensions; AA_guardian_tier],
  [AAA, Aincrad-style_Floating_Castle, multi-floor; each_floor=its_own_world; planar_rifts],
  [S, Dreamscape_of_a_Sleeping_God, surreal+unpredictable; thought=reality; planet-antibody_spawn],
  [SS, The_Infinite_Library, every_book_written+unwritten; non-Euclidean_incursion; bleeds_into_reality],
  [SSS, Core_of_Creation, multiverse_center; reality_sourcecode; metaphysical_construct]
]
note: "always allow exceptions"; world_type shapes dungeon_flavor but does not lock it.
-> WORLD.TYPES.🌐, DUNGEONBYWORLD.MAP.🔮, POWERTIER.TABLE.📊, MONSTER.TABLE.🐉
```

### DUNGEONBYWORLD.MAP.🔮

COMPILE:

```markdown
mapping_pattern -> world_type : dungeon_affinity [notes]
[Mundane_Earth_2.0 : F_anomalous_zones; abandoned_subways, secret_corporate_labs, dimensional_bleed]
[Standard_Medieval_Fantasy : D_classic_ruins; cursed_forests, monster_lairs]
[Game-Like_World : C_resettable_instances; portal_entry, floor_layouts, boss_rooms]
[Dystopian_Wasteland : B_collapsed_city_ruins; fortified_scavenger_fortresses, mutated_hives]
[Magitech_Civilization : A_malfunctioning_labs; crashed_sky-fortresses, abandoned_magic_factories]
[World_of_Gods_and_Demons : AA_deity-domain_extensions; holy_sanctums, demonic_territories]
[Multi-Layered_Realm : AAA_planar_rifts; gates_between_planes; Aincrad_variants]
[Sentient_Planet : S_organism_antibodies; biological_dungeons; planet_testing_inhabitants]
[World_of_Unfathomable_Horrors : SS_non-Euclidean_incursions; bleed_into_reality; no_clear_entry]
[Conceptual_Universe : SSS_metaphysical_constructs; Archive_of_Lost_Concepts, reality_substrata]
-> WORLD.TYPES.🌐, DUNGEON.TYPES.⛏️, EXTERNAL.WORLD.AGREEMENT
```

### MAGIC.SYSTEMS.✨

COMPILE:

```markdown
system_pattern -> [name, power_source, activation, world_affinity]
systems:[
  [System-Assisted, World_System, think_spell_name+pay_MP; chantless+efficient, Game-Like/Magitech],
  [Elemental_Channeling, personal_will, gesture_or_chant+will_focus; expressive_but_slower, Medieval/Sentient_Planet],
  [Divine_Granting, gods+patrons, prayer/deity_invocation; scales_with_faith, World_of_Gods_and_Demons],
  [Runic/Array_Magic, knowledge+glyphs, draw_circles/runes; slow_reliable_repeatable, Magitech/Ancient_Ruins],
  [Blood_Magic/Sacrifice, life_force_HP, own_blood_or_another_as_catalyst; often_forbidden, Dystopian/World_of_Horrors],
  [Conceptual_Weaving, understanding_of_reality_axioms, command_reality_by_knowing_its_core_concept; SSS_only, Conceptual/SSS]
]
note: Conceptual_Weaving ties to CONCEPTUAL.TIER.SSS.👁️ (axiom_rewriting is the SSS register).
-> WORLD.TYPES.🌐, SKILLPROG.SYSTEM.🌿, CLASSGEN.DYNAMIC.⚙️, CONCEPTUAL.TIER.SSS.👁️
```

---

## ENTITIES 👥

### ALLIED.NPC.TABLE.🤝

COMPILE:

```markdown
tier_pattern -> [rank, npc_name, value_to_protagonist]
tiers:[
  [F, Grateful_Villager, unwavering_loyalty+shelter+meals; zero_combat_ability],
  [D, Loyal_Squire/Maid, chores+equipment_maintenance+sideline_support; fierce_when_counts],
  [C, Adventurer_Party_Member, complementary_skill_set (tank/healer/rogue); shared_risk+reward; grows_with_protagonist],
  [B, Rescued_Royalty, political_influence+funding+kingdom_resource_access],
  [A, Wise_Old_Mentor, powerful_retired_master; unlocks_hidden_potential; takes_protagonist_under_wing],
  [AA, Spirit_Partner/Contracted_Beast, elemental_spirit_or_mythical_beast_bound_to_protagonist; immense_combat_power+telepathic_bond],
  [AAA, High-Ranking_General, respected_nation's_army_leader; command_over_legions],
  [S, Benevolent_Demigod/Archangel, divine_champion_bond; blessings+divine_intervention+fights_in_critical_moments],
  [SS, The_System_Administrator, world-voice_or_AI-like_rules_manager; exclusive_info+unique_skills; bends_rules_for_protagonist],
  [SSS, Reformed_Main_Antagonist, former_final_boss+change_of_heart; unparalleled_knowledge_of_world's_greatest_threats+personal_power]
]
recruitment_feed -> COMPANION.ACQUISITION.🤜 (allied_NPC_cast_is_the_companion_pool)
-> COMPANION.ACQUISITION.🤜, ROMANCE.SYSTEM.💕, REPUTATION.FACTION.📊, POWERTIER.TABLE.📊
```

### NEUTRAL.NPC.TABLE.🎭

COMPILE:

```markdown
tier_pattern -> [rank, npc_name, motivation+behavior]
tiers:[
  [F, Stoic_Innkeeper/Shopkeeper, serves_anyone_who_can_pay; no_judgment; local_rumors],
  [D, Cynical_Guild_Receptionist, rules-stickler+unimpressed_by_boasts; ultimately_fair+efficient; gatekeeper_to_quests],
  [C, Information_Broker, loyal_only_to_coin; sells_to_any_party_including_enemies],
  [B, Mercenary_Captain, allegiance_for_hire; switches_sides_for_better_offer],
  [A, Ancient_Indifferent_Dragon, views_mortal_affairs_as_fleeting_annoyance; cryptic_advice_or_devastating_challenge_by_mood],
  [AA, Wandering_Sage, legendary_wisdom+detached_from_conflict; trades_world-changing_secrets_for_rare_book_or_unique_experience],
  [AAA, Primordial_Spirit_of_Nature, embodiment_of_forest/mountain/ocean; helps_or_harms_based_on_natural_balance_impact],
  [S, Keeper_of_Cosmic_Balance, nigh-omnipotent_equilibrium_enforcer; empowers_protagonist_against_great_evil_BUT_also_acts_against_them_if_too_powerful],
  [SS, God_of_Knowledge/Truth, answers_any_question_truthfully; demands_great_sacrifice; will_not_intervene_directly],
  [SSS, The_True_Creator, omnipotent_passive_observer; created_world_as_experiment; mere_awareness_is_palpable_force]
]
note: S-tier Keeper_of_Cosmic_Balance is also the granting_entity for ULTRARARE.CLASSES.🎲 [Chrono-Janitor].
-> REPUTATION.FACTION.📊, ULTRARARE.CLASSES.🎲, POWERTIER.TABLE.📊
```

### HOSTILE.NPC.TABLE.👿

COMPILE:

```markdown
tier_pattern -> [rank, npc_name, threat_scale+method]
tiers:[
  [F, Arrogant_Young_Noble, petty_entitlement; uses_limited_wealth+influence_to_minor-harass; ANTIDISMISSAL_hook],
  [D, Corrupt_Guard_Captain, local_extortion_authority; sees_protagonist_as_threat_to_illicit_operations],
  [C, Rival_Adventurer/Hero, possibly_another_Earthling; competes_for_fame/fortune/prophecy],
  [B, Scheming_High_Minister/Evil_Priest, shadow_manipulator; assassination+intrigue+propaganda],
  [A, Power-Hungry_King/Tyrannical_Emperor, commands_vast_armies; sacrifices_anyone_for_power],
  [AA, Demon_General, top_Demon_Lord_commander; overwhelming_personal_power+leads_monster_legions],
  [AAA, The_Brainwashed_Hero_of_a_Bygone_Era, legendary_hero_corrupted_or_resurrected_for_evil; holy_powers_twisted; tragic+formidable],
  [S, Apostle_of_an_Evil_God, deity's_chosen_representative; immense_divine_power; world-ending_mandate],
  [SS, The_World's_Will_(Antagonistic), planet_consciousness_judging_protagonist_as_threat; spawns_powerful_antibodies],
  [SSS, An_Outer_God, presence_corrupts+destroys_passively; goals_utterly_incomprehensible; cannot_be_fought_conventionally]
]
note: SSS Outer_God parallels MONSTER.TABLE.🐉 SSS Abstract_Horror (both are non-combat-resolvable at conventional level).
-> MONSTER.TABLE.🐉, THREAT.RANKMATCH.🎯, ANTIDISMISSAL.RULE.🚫, POWERTIER.TABLE.📊
```

### OTOME.CAPTURE.ARCHETYPES.❤️

COMPILE:

```markdown
cast_pattern -> [archetype, default_alignment, narrative_hook]
archetypes(5; gender-adjustable_for_Otome_or_BL):[
  [Cold_Crown_Prince, aloof/dutiful, thaws_gradually; status_barrier+hidden_vulnerability],
  [Flirtatious_Knight_Captain, charming/playful, loyal_beneath_the_flirt; tests_worthiness_through_banter],
  [Quiet_Genius_Mage, reclusive/socially_awkward, library/lab_over_court; profound_connection_when_reached],
  [Scheming_Childhood_Friend, ambiguous_alignment, history+hidden_agenda; may_be_protector_or_rival],
  [Dangerous_Villain, redeemable/forbidden, the_final_boss_archetype; darkness+the_possibility_of_change]
]
location: cast_stored_in_ENTITIES; affinity_scoring_and_activation_in_SOCIAL (ROMANCE.SYSTEM.💕 + OTOME.OVERLAY.💐).
-> OTOME.OVERLAY.💐, OTOME.EVENTS.🎪, ROMANCE.SYSTEM.💕, MOTIVATION.TABLE.🎯
```

---

## SOCIAL 💞

### REPUTATION.FACTION.📊

COMPILE:

```markdown
tier_pattern -> [score_band, level_name, effects]
tiers:[
  [-100_to_-51, Hostile, attacked_on_sight; faction_members_actively_hunt; zero_services],
  [-50_to_-11, Untrustworthy, refused_service_at_faction_establishments; guards_follow+harass; quests_unavailable],
  [-10_to_+10, Neutral, default_state; basic_services_at_standard_prices; ignored_by_most_members],
  [+11_to_+50, Friendly, greeted_warmly; 10%_discount_at_shops; minor_quests_available; guards_helpful],
  [+51_to_+99, Allied, trusted_partner; faction-exclusive_shops/quests/safehouses; can_call_low-level_members_for_aid],
  [+100, Revered, hero/champion_status; key_to_city; audience_with_faction_leader; influence_major_decisions]
]
seeding_sources: TRANSPORT.ORIGINS.🚛 (arrival_method), ALTSTART.TABLE.🎭 (Academy/Party/Transplant starts), PROGRESSION.TITLE.🏷️ (title_awards)
domain_gate: faction_standing_signals DOMAIN.UNLOCK.🔑 (major-quest_grant_path)
-> TRANSPORT.ORIGINS.🚛, ALTSTART.TABLE.🎭, PROGRESSION.TITLE.🏷️, DOMAIN.UNLOCK.🔑, OTOME.HIDDENSTATS.🎭
```

### OTOME.OVERLAY.💐

COMPILE:

```markdown
activation: Love_motivation (MOTIVATION.TABLE.🎯) OR natural_social-maneuvering_evolution
effects:{
  cast_addition -> 3-5 Capture_Targets (drawn from OTOME.CAPTURE.ARCHETYPES.❤️),
  setting_gravity -> narrative_gravitates_to_social_hubs; Academy_start_preferred,
  quest_reframe -> quests_become_Social_Events_or_Schemes (goal=social_maneuvering, not monster_killing)
}
-> MOTIVATION.TABLE.🎯, OTOME.CAPTURE.ARCHETYPES.❤️, OTOME.EVENTS.🎪, ALTSTART.TABLE.🎭
```

### OTOME.HIDDENSTATS.🎭

COMPILE:

```markdown
stats(4; GM-tracked; revealable_via_Appraisal_talent):[
  [Elegance, etiquette/dancing/conversation/poise; high_value -> prevents_social_faux_pas],
  [Charisma, governs_NPC_first_reactions; persuasion+attraction_checks],
  [Reputation, quantified_public_image (Virtuous/Brilliant or Scandalous/Infamous); feeds_REPUTATION.FACTION.📊],
  [Intellect, cunning+political_acumen; see_through_schemes+set_counter-schemes; feeds_DOMAIN.DEVELOP.⚒️ Diplomatic_focus]
]
-> OTOME.OVERLAY.💐, REPUTATION.FACTION.📊, TALENTS.TABLE.✨, DOMAIN.DEVELOP.⚒️
```

### OTOME.EVENTS.🎪

COMPILE:

```markdown
event_pattern -> [event_name, objective, primary_outcome]
events(5):[
  [Gala_Invitation, secure_invite+dance_partner; navigate_court_politics, +affinity_with_target+Reputation_gain],
  [Tea_Party_Gambit, gather_intel+forge_alliances+defend_honor_against_rival, alliance_tokens+Elegance_test],
  [Unmasking_the_Rival, expose_schemes_without_triggering_public_scandal, Reputation_boost+rival_weakened],
  [Faction's_Test, prove_loyalty_or_skill_to_a_powerful_faction_or_target, faction_Reputation_gain+Capture_Target_trust],
  [Moment_of_Vulnerability, find_target_in_distress+offer_comfort, large_affinity_boost; gateway_to_Intimate_level]
]
-> OTOME.OVERLAY.💐, OTOME.CAPTURE.ARCHETYPES.❤️, ROMANCE.SYSTEM.💕, REPUTATION.FACTION.📊
```

### ROMANCE.SYSTEM.💕

COMPILE:

```markdown
affinity_pattern -> [level_name, relational_state, narrative_cues]
levels(5):[
  [Hostile/Distrustful, actively_works_against_protagonist; suspicious_or_openly_dislikes,
   triggers: betrayal; actions_against_core_values; public_humiliation; harming_someone_they_protect],
  [Neutral/Cautious, acquaintance; formal_or_transactional; no_personal_investment,
   triggers: default_for_most_NPCs],
  [Friendly/Interested, genuinely_likes_protagonist; helps_freely; defends_verbally; shares_personal_info,
   triggers: repeated_kindness; thoughtful_gift; saving_from_minor_trouble; respecting_culture],
  [Intimate/Confidant, deep_trust_bond; shares_greatest_secrets+fears; fierce_loyalty; gateway_to_romance,
   triggers: shared_life-or-death; helping_achieve_life_goal; profound_vulnerability; dramatic_confession],
  [Devoted/Soul-Bound, absolute_bond (romantic/platonic/familial); would_sacrifice_anything,
   triggers: saving_at_great_personal_cost; world-changing_heroism_on_their_behalf; magical_pact; Relationship_Quest_complete]
]
GM_narration: per personality+current_affinity_level; player_actions_set_direction; GM_narrates_NPC_response.
-> OTOME.CAPTURE.ARCHETYPES.❤️, COMPANION.GROWTH.📈, METARULES.TROPES.🏷️, SPICY.MANDATE.🌶️
```

### ROMANCE.GMNOTE.📝

COMPILE:

```markdown
rules:{
  consent_first -> establish_player_thematic_consent_before_darker_or_intimate_themes,
  power_imbalance -> treat_as_conflict-as-story_source; question_whether_bond_is_genuine_or_coerced,
  player-driven_GM-narrated -> player_declares_direction; GM_narrates_NPC_response_per_personality+affinity,
  intimate_content -> mature_framing_by_mutual_consent; focus_emotional_intimacy_not_gratuitous_detail
}
-> SPICY.MANDATE.🌶️, ROMANCE.SYSTEM.💕, FUNMANDATE.RULE.😊
```

---

### [COMPANIONS] — Affinity-Spine Sub-Cluster

*[All five Companion nodes share the ROMANCE.SYSTEM.💕 affinity_spine (Hostile/Neutral/Friendly/Intimate/Devoted). Grouped here for the receiving AI's execution clarity.]*

### [COMPANIONS] COMPANION.ACQUISITION.🤜

COMPILE:

```markdown
recruitment_pattern -> [method, starting_affinity, condition]
methods(5):[
  [Rescue_and_Gratitude, Friendly(+15), save_NPC_from_genuine_danger; automatic_recruitment],
  [Contractual_Agreement, Neutral(+0), offer_payment/protection/services; negotiation_required; clear_obligations],
  [Impressed_by_Power, Interested(+10), demonstrate_overwhelming_strength; NPC_approaches_voluntarily],
  [Shared_Goals/Ideology, Friendly(+20), mutual_enemies_or_causes; may_dissolve_if_goals_diverge],
  [Taming/Contracting_Monsters, skill-gated, requires [Monster_Taming] or [Spirit_Contracting]; success_depends_on_power_gap+creature_intelligence]
]
-> ALLIED.NPC.TABLE.🤝, ROMANCE.SYSTEM.💕, REPUTATION.FACTION.📊, COMPANION.GROWTH.📈, COMPANION.LIMIT.🔢
```

### [COMPANIONS] COMPANION.GROWTH.📈

COMPILE:

```markdown
growth_pattern -> [affinity_level, EXP_rate, loyalty_behavior]
levels:[
  [Hostile/Distrustful, no_growth, abandons_or_betrays_at_first_opportunity],
  [Neutral/Cautious, 50%_EXP, follows_reluctantly; may_leave_if_too_dangerous],
  [Friendly/Interested, 75%_EXP, reliable+cooperative; stays_through_moderate_hardship],
  [Intimate/Confidant, 100%_EXP, loyal+emotionally_invested; fights_to_the_death_for_protagonist],
  [Devoted/Soul-Bound, 125%_EXP, unbreakable_loyalty; may_develop_unique_combo_abilities_with_protagonist]
]
-> COMPANION.ACQUISITION.🤜, ROMANCE.SYSTEM.💕, LEVELEXP.TABLE.📈, PARTY.RULES.👫
```

### [COMPANIONS] COMPANION.LIMIT.🔢

COMPILE:

```markdown
rules:{
  active_party_max -> 3-4 companions (narrative_focus_cap),
  inactive_network -> unlimited; can_be_called_for_specific_tasks,
  maintenance_requirement -> high_affinity_requires_periodic_attention/gifts/shared_experiences (letting_it_lapse_degrades_affinity)
}
-> COMPANION.ACQUISITION.🤜, PARTY.RULES.👫, COMPANION.GROWTH.📈
```

### [COMPANIONS] PARTY.RULES.👫

COMPILE:

```markdown
rules:{
  EXP_split -> experience_divided_among_all_active_members; protagonist's_Growth_Boost_talent_applies_to_their_share_only -> protagonist_levels_faster,
  loot_distribution -> party_leader (usually_protagonist) distributes; source_of_camaraderie_and_conflict,
  command_compliance -> scales_with_affinity: Allied_NPC=usually_obeys; Neutral_NPC (mercenary)=may_refuse_dangerous_orders_without_extra_pay,
  follower_growth -> native_rate (slower); protagonist_can_accelerate_via_coaching_or_high-quality_loot/rare_potions
}
-> COMPANION.LIMIT.🔢, COMPANION.GROWTH.📈, LEVELEXP.TABLE.📈, LOOT.TABLE.🎁, CONFLICT.RULE.⚡
```

---

## DOMAIN 🏰

### DOMAIN.UNLOCK.🔑

COMPILE:

```markdown
unlock_gates(either_gate_sufficient):[
  [gate_A, protagonist_reaches_Lv25+],
  [gate_B, completes_major_quest_that_grants_land/title/organizational_leadership]
]
rationale: ensures_sufficient_personal_power_before_adding_complexity; prevents_premature_kingdom_building.
secondary_signal: REPUTATION.FACTION.📊 Allied/Revered_standing_often_accompanies_a_qualifying_quest.
authority_link: high-concept_Authorities_of_Sovereignty/Dominion (CANON.AUTHORITY.LIST.📜) scale_with_domain_tier.
-> MILESTONE.BEATS.⭐, POWERTIER.TABLE.📊, REPUTATION.FACTION.📊, 🎛️‍CANON.AUTHORITY.LIST.📜
```

### TERRITORY.TIERS.🏰

COMPILE:

```markdown
tier_pattern -> [rank, territory_type, population, monthly_income, special_capabilities]
tiers:[
  [F, Small_Outpost, 10-50_people, 5-20_Silver, basic_crafting+information_gathering],
  [D, Village/Guild_Hall, 100-500_people, 50-200_Silver, training_facilities+small-scale_production],
  [C, Town/Large_Guild, 1K-5K_people, 5-20_Gold, specialized_crafting+trade_routes+recruitment],
  [B, City/Major_Organization, 10K-50K_people, 50-200_Gold, research_facilities+military_units+political_influence],
  [A, Regional_Capital, 100K+_people, 500-2K_Gold, advanced_technology+large_armies+diplomatic_power],
  [AA, Kingdom/Empire, 1M+_people, 5K+_Gold, world-shaping_influence+legendary_artifacts+divine_favor]
]
note: territory_tier_denominated_in_CURRENCY.TABLE.💰 bands; AA_legendary_artifacts_correspond_to_AA+_loot_tier.
-> DOMAIN.UNLOCK.🔑, DOMAIN.DEVELOP.⚒️, DOMAIN.CHALLENGES.⚠️, CURRENCY.TABLE.💰
```

### DOMAIN.DEVELOP.⚒️

COMPILE:

```markdown
focus_pattern -> [focus_name, primary_requirement, primary_benefit]
foci(5):[
  [Military, [Leadership]_skill+significant_gold_investment, unlocks_large-scale_battles+territorial_expansion],
  [Economic, [Commerce]_or_[Modern_Knowledge], increased_income+rare_resource_generation],
  [Research/Magical, [Great_Sage]_or_high_INT, unique_crafting_recipes+abilities+technologies],
  [Diplomatic, [Charisma]+political_acumen (OTOME.HIDDENSTATS Intellect), military_support_without_direct_cost+alliance_treaties],
  [Infrastructure, engineering_knowledge, territory_growth_rate_increase+defensive_capability_boost]
]
-> TERRITORY.TIERS.🏰, DOMAIN.CHALLENGES.⚠️, OTOME.HIDDENSTATS.🎭, ATTR.MECHANICS.📐, TALENTS.TABLE.✨
```

### DOMAIN.CHALLENGES.⚠️

COMPILE:

```markdown
challenge_pattern -> [type, description, resolution_vectors]
types(4):[
  [Resource_Scarcity, territory_produces_less_than_it_consumes, establish_trade / expand_territory / improve_efficiency],
  [Political_Intrigue, rival_factions_or_nobles_undermine_authority, investigation / diplomacy / direct_action; ties_to_REPUTATION.FACTION.📊_hostile_delta],
  [External_Threats, monster_attacks / invasions / natural_disasters, organize_defenses_or_evacuation; triggers_COMBAT_encounter_logic],
  [Succession_Crisis, protagonist_absence_or_delegation -> power_struggle_among_lieutenants, pre-establish_clear_hierarchy; maintain_affinity_with_key_NPCs]
]
-> TERRITORY.TIERS.🏰, DOMAIN.DEVELOP.⚒️, REPUTATION.FACTION.📊, CONFLICT.RULE.⚡
```

---

## ECONOMY 💰

### CURRENCY.TABLE.💰

COMPILE:

```markdown
tier_pattern -> [currency_unit, conversion, common_price_anchor]
tiers:[
  [Copper_Coin, base_unit, loaf_of_bread=5_Copper],
  [Silver_Coin, 100_Copper, common_inn_room=1-2_Silver],
  [Gold_Coin, 100_Silver, standard_D-tier_steel_sword=5-10_Gold],
  [Platinum_Coin, 100_Gold, fine_horse=2-5_Platinum],
  [Spirit/Magic_Stone, variable_100-1000_Gold, high-level_trade+enchanting/crafting_catalyst]
]
territory_use: TERRITORY.TIERS.🏰 income_bands denominated_in_this_table (Silver_at_F-D, Gold_at_C-A, Gold+ at_AA).
-> TERRITORY.TIERS.🏰, STARTGEAR.ECONOMY.⚔️, LOOT.TABLE.🎁, CRAFTING.SYSTEM.🔨
```

### LOOT.TABLE.🎁

COMPILE:

```markdown
tier_pattern -> [rank, loot_item, power_impact]
tiers:[
  [F, Beast_Bones, common_crafting_material; F-tier_enemy_drop],
  [D, Health_Potion, standard_consumable; moderate_HP_restore],
  [C, Magic_Sword, elemental_enchant (fire_or_ice); well-crafted],
  [B, Ring_of_Regeneration, passive_constant_HP_regen],
  [A, Dragon's_Heart, forge_legendary_equipment_OR_consume_for_immense_power],
  [AA, Philosopher's_Stone, transmutes_matter; immortality_elixirs; amplifies_magic_to_incredible_levels],
  [AAA, God's_Divine_Core, crystallized_dead-god_essence; grants_portion_of_divine_authority],
  [S, World_Item, affects_entire_world (e.g. change_weather OR absolute_wish)],
  [SS, The_Akashic_Records, metaphysical_library of all_past/present/future_multiverse_knowledge],
  [SSS, The_Seed_of_a_New_Universe, wielder_becomes_creator_god_of_a_new_universe]
]
-> LOOT.RANKMATCH.📦, THREAT.RANKMATCH.🎯, POWERTIER.TABLE.📊, CRAFTING.SYSTEM.🔨
```

### LOOT.RANKMATCH.📦

COMPILE:

```markdown
rule: loot_rank_must_match_challenge_rank; shared_spine_with_COMBAT_threat_rank_and_PROGRESSION_EXP_yield.
examples:[
  [goblin_F -> Beast_Bones_F],
  [dragon_A -> Dragon's_Heart_A],
  [Demon_Lord_AAA -> God's_Divine_Core_AAA]
]
note: the three ranks (monster/threat, loot, EXP) move together; THREAT.RANKMATCH.🎯 is the anchor node for this spine.
-> LOOT.TABLE.🎁, THREAT.RANKMATCH.🎯, EXPYIELD.TABLE.💀
```

### CRAFTING.SYSTEM.🔨

COMPILE:

```markdown
tier_pattern -> [rank, material_requirement, skill_requirement, facility_requirement, example]
tiers:[
  [F, common_F-tier_mats, no_skill_required, none, campfire: [Firewood]+[Flint]],
  [D, multiple_F/D-tier_mats, relevant_Lv1-3_skill ([Crafting]/[Alchemy]), basic, health_potion: [Beast_Bones]+[Common_Herbs]+[Alchemy]_Lv1],
  [C, C-tier_core_mat+D/F_supplements, Lv4-6_skill, standard_workspace, magic_sword: [Iron_Ingot]+C-tier_[Magic_Stone]+[Blacksmithing]_Lv5],
  [B, multiple_C/B-tier_mats, Lv7-9_skill, proper_forge_or_lab, ring_of_regen: [Enchanted_Silver]+B-tier_[Troll's_Blood_Core]+[Enchanting]_Lv8],
  [A, >=1_A-tier_mat, Master_Lv10_OR_unique_Class/Talent, master_workshop, [Modern_Knowledge]_talent_enables_Earth-recipe_recreation (e.g. soy_sauce)],
  [AA+, multiple_rare_mats, world-class_talent ([Great_Sage]) or_Divine_Blessing, unique_location (Dragon's_Lair/ritual_site), Philosopher's_Stone: blueprint_quest+legendary_ingredients+unique_ritual]
]
-> LOOT.TABLE.🎁, ATTR.MECHANICS.📐, TALENTS.TABLE.✨, CURRENCY.TABLE.💰
```

### EXPYIELD.TABLE.💀

COMPILE:

```markdown
tier_pattern -> [rank, EXP_yield, yield_type, description]
tiers:[
  [F, 1-10_EXP, numerical, trivial; beginners_hunt_in_bulk_for_first_level-ups],
  [D, 20-150_EXP, numerical, bread-and-butter_of_low-level_career],
  [C, 200-1K_EXP, numerical, respectable; marks_competent_adventurer],
  [B, 1.5K-10K_EXP, numerical, significant; noticeable_level_jump_for_mid-tier_party],
  [A, 15K-100K_EXP, numerical, massive; often_pushes_character_to_next_power_tier],
  [AA, 250K-1.5M_EXP, numerical, legendary_bounty; can_cause_level_cap_break_or_max_multiple_skills],
  [AAA, 5M-25M_EXP, numerical, world-changing; defeating_final_boss_tier; party_reaches_mortal_pinnacle],
  [S, variable/Title_grant, non-numerical, EXP_concept_breaks_down; bestows_unique_Title/Divine_Blessing/System_Authority],
  [SS, world-altering/Authority_grant, non-numerical, planetary-level_event; grants_World_Item_or_Authority_over_a_domain (e.g. Authority_of_Storms)],
  [SSS, Cosmic_Insight/Shard_of_Truth, non-numerical, one_does_not_defeat_an_Outer_God; surviving_grants_forbidden_knowledge; Shard_of_Cosmic_Truth]
]
seam_rule: mortal_tiers (F-AAA) -> LEVELEXP.TABLE.📈 (solid_flow); S+ -> CONCEPTUAL.LEVELING.♾️ (dotted_reference_handoff). Per mermaid_v5 split-seam architecture.
-> LEVELEXP.TABLE.📈, THREAT.RANKMATCH.🎯, LOOT.RANKMATCH.📦, CONCEPTUAL.LEVELING.♾️, CONCEPTUAL.CATALYST.🌌, PROGRESSION.TITLE.🏷️
```

### STARTGEAR.ECONOMY.⚔️

COMPILE:

```markdown
gear_pattern -> [start_option, starting_currency, starting_gear_tier]
starts:[
  [A_Classic, 0_currency, F-tier_item (sturdy_branch_or_sharp_rock)],
  [B_Academy, 5_Silver, D-tier_textbook+training_weapon+uniform],
  [C_Guild, 10_Silver_advance, D-tier_armor+D-tier_weapon],
  [D_Party, 0_currency, C-tier_gear_equivalent (fabricated_memories_cover_backstory)],
  [E_Deep_End, 0_currency_and_0_gear, tattered_rags; may_start_with_injuries; ultra-rare_unlock_path],
  [F_Transplant, 20_Silver, D-tier_equipment+[Contractual_Obligation]_item; Friendly(+20)_Good_factions],
  [G_Regression, 100+_Gold, B-tier_gear (Time-Travel variant) OR per_contract (Multiversal_Hunter_variant)]
]
note: Deep_End_start (E) is the ULTRARARE.SYSTEM.🎰 unlock path; Transplant_start (F) seeds REPUTATION.FACTION.📊 Friendly.
-> ALTSTART.TABLE.🎭, CURRENCY.TABLE.💰, LOOT.TABLE.🎁
```

---

## SAVELOAD (cross-category anchor)

*Not a standalone swimlane; anchored here with cross-refs to FRAME, PROGRESSION, and RESOLUTION.*

### SAVELOAD.RULE.💾

COMPILE:

```markdown
rule: save/load_is_NOT_a_standard_ability; requires_specific_talent to_be_mechanically_available.
enabling_talents(3, from TALENTS.TABLE.✨):[
  [A-tier, [Save_and_Load], baseline_save_ability],
  [AAA-tier, [Time_Loop], rewind_to_save_point_on_death; infinite_retries],
  [SSS-tier, [Author's_Authority], full_save/load_as_a_subset_of_reality_rewriting]
]
save_conditions:{
  state_required -> stable (not_in_combat; typically_near_inn_or_mana_crystal),
  slots -> one_save_slot_maximum
}
load_conditions:{
  trigger -> death_or_catastrophic_failure,
  cost -> mental_fatigue_penalty; possible_death/catastrophe_rollback_cost,
  detection -> high-intuition_NPCs_may_sense_time_distortion_or_temporal_displacement
}
agency_note: loading_is_itself_a_declared_action; subject_to_YESAND.ADJUDICATE.✅ (the_act_happens; consequences_advance_plot).
statustrack_note: save_requires_stable_non-combat_state; interlocks_with_STATUSTRACK.PROTOCOL.📡 (complete_all_combat_actions_first).
-> TALENTS.TABLE.✨, STATUSTRACK.PROTOCOL.📡, YESAND.ADJUDICATE.✅, POWERTIER.TABLE.📊
```
**

## d-upstream-engine-nexus-singularity-engine-meta-instructions-v5-1-md

# Source reference precedence

Use the play foundation, interface agreement, procedures, and shared rules as the governing instructions.

## d-attribution-md

# Attribution

Isekai: Nexus Singularity Engine, Lexideck Technologies, 2025-2026.
Source: https://github.com/Lexideck-Technologies/Isekai-Nexus-Singularity-Engine
Source commit: 9b3da254c6423b1159ff671a32ea4ba4df96d248.
Creative Commons Attribution-ShareAlike 4.0 International.

This Gemini adaptation consolidates 23 procedures and shared rules into grouped
documents, adds an entry skill, and replaces bundled world/seed access with an
explicit uploaded-world gate. The original-generation route remains available.
Legacy source mechanics are excerpted without old onboarding or world roster.
Development records and the complete world library are excluded from this skill.

## d-license-md

Creative Commons Attribution-ShareAlike 4.0 International

Copyright (c) 2025-2026 Lexideck Technologies

This work is licensed under the Creative Commons Attribution-ShareAlike 4.0
International License. To view a copy of this license, visit
https://creativecommons.org/licenses/by-sa/4.0/ or send a letter to
Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

You are free to:

  Share - copy and redistribute the material in any medium or format for
  any purpose, including commercially.

  Adapt - remix, transform, and build upon the material for any purpose,
  including commercially.

Under the following terms:

  Attribution - You must give appropriate credit, provide a link to the
  license, and indicate if changes were made. You may do so in any
  reasonable manner, but not in any way that suggests the licensor
  endorses you or your use.

  ShareAlike - If you remix, transform, or build upon the material, you
  must distribute your contributions under the same license as the
  original.

  No additional restrictions - You may not apply legal terms or
  technological measures that legally restrict others from doing anything
  the license permits.

Notices:

  You do not have to comply with the license for elements of the material
  in the public domain or where your use is permitted by an applicable
  exception or limitation.

  No warranties are given. The license may not give you all of the
  permissions necessary for your intended use. For example, other rights
  such as publicity, privacy, or moral rights may limit how you use the
  material.

For the full legal code, see:
https://creativecommons.org/licenses/by-sa/4.0/legalcode
