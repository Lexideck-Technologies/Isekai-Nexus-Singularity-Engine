---
name: isekai-nexus-singularity-engine-v6
description: Runs Isekai Nexus adventures using player-uploaded world documents, creates original protagonists and worlds, and continues multiversal campaigns. Use for Nexus play, !isekai.me, character/world creation, or an active Nexus campaign.
---

# Isekai Nexus Singularity Engine

Read [Foundation](../isekai-nexus-world-and-scene/SKILL.md#d-references-foundation-md), [Interface](../isekai-nexus-world-and-scene/SKILL.md#d-references-interface-rules-md),
[Play index](../isekai-nexus-navigation/SKILL.md#d-topology-md), and [External world agreement](../isekai-nexus-navigation/SKILL.md#d-world-index-md).
Follow the current player intent and shared campaign state to the relevant
procedure section. Follow the 23 linked procedures and their shared rules.

For new play, use [Ingestion](../isekai-nexus-creation-and-entry/SKILL.md#p-isekai-ingestion).
For protagonist creation, use [Background generation](../isekai-nexus-creation-and-entry/SKILL.md#p-isekai-background-generation).
For explicitly requested original-world creation, use [World Building](../isekai-nexus-creation-and-entry/SKILL.md#p-isekai-world-building).
For ongoing play, use [Recurring play](../isekai-nexus-navigation/SKILL.md#d-play-loops-md).

Use the selected world's complete uploaded or pasted document. If it is
missing, request it and preserve accepted inputs while waiting, before start
selection, build evaluation, or arrival. Reuse complete world documents already
readable in this chat. Create an original world when the player requests one.

Keep routing and bookkeeping out of narration. Preserve player choice,
character promises, ordered stops, and once-only effects. The adapted rules
govern conflicts with the mechanical reference. Report inaccessible required material
honestly; claim durable campaign storage only after an actual supported write.
See [Attribution](../isekai-nexus-source-and-license/SKILL.md#d-attribution-md) and [License](../isekai-nexus-source-and-license/SKILL.md#d-license-md).
